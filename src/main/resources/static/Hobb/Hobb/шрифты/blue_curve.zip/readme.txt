Blue Curve is a new grotesque font created by Dimitri Antonov.
This font needs to be in your collections and is perfect for your next design projects.

Blue Curve includes light, regular and bold versions.
Free for all.

https://www.behance.net/ed67b3fc

